﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JournalAbsent
{
	public class JournalRow
	{
		public DateTime Date { get; set; }
		public int StudentBookNumber { get; set; }
		public string StudentName { get; set; }
		public string Group { get; set; }
		public string Discipline { get; set; }
		public int CoupleNumber { get; set; }
	}
}
