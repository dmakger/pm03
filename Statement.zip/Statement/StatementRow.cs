﻿using System;

namespace Statement
{
	public class StatementRow
	{
		public DateTime Date { get; set; }
		public int StudentBookNumber { get; set; }
		public string StudentName { get; set; }
		public string Group { get; set; }
		public string Discipline { get; set; }
		public int Mark { get; set; }
	}
}
